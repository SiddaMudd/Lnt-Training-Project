package com.seller.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.seller.Exception.ProductAlreadyExistException;
import com.seller.Exception.ProductNotFoundException;
import com.seller.bean.Product;
import com.seller.service.ProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value = { "/product" })
public class ProductController {
	@Autowired
	ProductService productService;

	@GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> getProductById(@PathVariable("id") long id) throws ProductNotFoundException {
		System.out.println("Fetching Product with id " + id);
		Product product = productService.findById(id);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

	@PostMapping(value = "/create", headers = "Accept=application/json")
	public ResponseEntity<Product> createProduct(@RequestBody Product product, UriComponentsBuilder ucBuilder) throws ProductAlreadyExistException {
		System.out.println("Creating Product " + product.getName());
		Product product1 = productService.createProduct(product);
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/product/{id}").buildAndExpand(product.getId()).toUri());
		return new ResponseEntity<Product>(product1, headers, HttpStatus.CREATED);
	}

	@GetMapping(value = "/get", headers = "Accept=application/json")
	public List<Product> getAllProduct(@RequestParam(required = false) Long sellerId, @RequestParam(defaultValue = "0") Integer pageNo,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(defaultValue = "id") String sortBy) {
		System.out.println("in get()");
		List<Product> tasks = null;
		if (sellerId == null) {
			tasks = productService.getProducts(pageNo,pageSize,sortBy);
		} else {
			
			tasks = productService.findBySellerId(sellerId);
		}
		return tasks;

	}

	@PutMapping(value = "/update", headers = "Accept=application/json")
	public ResponseEntity<Product> updateProduct(@RequestBody Product currentProduct) throws ProductNotFoundException {
		System.out.println("sd");
		Product product = productService.findById(currentProduct.getId());
		productService.update(currentProduct, currentProduct.getId());
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

	@DeleteMapping(value = "/{id}", headers = "Accept=application/json")
	public ResponseEntity<Product> deleteProduct(@PathVariable("id") long id) throws ProductNotFoundException {
		Product product = productService.findById(id);
		productService.deleteProductById(id);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

}
