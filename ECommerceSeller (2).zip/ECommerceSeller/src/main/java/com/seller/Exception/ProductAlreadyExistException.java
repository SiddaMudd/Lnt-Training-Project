package com.seller.Exception;

public class ProductAlreadyExistException extends Exception{
	String productName;
	public ProductAlreadyExistException(String productName){
		this.productName = productName;
	}
	@Override
	public String toString() {
		return "Product Already Exist  with [productName=" + productName + "]";
	}
	
}
