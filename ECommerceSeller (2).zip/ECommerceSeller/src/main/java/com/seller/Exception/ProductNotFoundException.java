package com.seller.Exception;

public class ProductNotFoundException extends Exception{
	String productId;
	public ProductNotFoundException(String productId){
		this.productId = productId;
	}
	@Override
	public String toString() {
		return "Product Not Found with [productId=" + productId + "]";
	}
	
}
