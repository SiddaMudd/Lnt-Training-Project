package com.seller.repository;

import org.springframework.data.repository.CrudRepository;

import com.seller.bean.Seller;
public interface SellerRepository extends CrudRepository<Seller, Long>
{
	

}
