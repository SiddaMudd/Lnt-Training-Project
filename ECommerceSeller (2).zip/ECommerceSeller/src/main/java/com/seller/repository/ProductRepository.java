package com.seller.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.seller.bean.Product;
public interface ProductRepository extends PagingAndSortingRepository<Product, Long>
{
	List<Product> findBySellerId(long id);

}
