package com.seller.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.seller.Exception.ProductAlreadyExistException;
import com.seller.Exception.ProductNotFoundException;
import com.seller.bean.Product;
import com.seller.repository.ProductRepository;

@Service
 @Transactional
public class ProductService {
	@Autowired
	ProductRepository productRepository;

	public Product createProduct(Product product) throws ProductAlreadyExistException {
		// TODO Auto-generated method stub
		Optional<Product> p = productRepository.findById(product.getId());
		if(p.isPresent()){
			throw new ProductAlreadyExistException(p.get().getName());
		}
		return productRepository.save(product);
	}

	public List<Product> getProducts(Integer pageNo, Integer pageSize, String sortBy) {
		// TODO Auto-generated method stub
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
		return (List<Product>) productRepository.findAll(paging).get().collect(Collectors.toList());
	}

	public Product findById(long id) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		Optional<Product> p = productRepository.findById(id);
		if(!(p.isPresent())){
			throw new ProductNotFoundException(" "+id);
		}
		return productRepository.findById(id).get();
		
	}
	public List<Product> findBySellerId(long id) {
		// TODO Auto-generated method stub
		
		return productRepository.findBySellerId(id);
		
	}

	public Product update(Product product, long l) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		Optional<Product> p = productRepository.findById(l);
		if(!(p.isPresent())){
			throw new ProductNotFoundException(p.get().getName());
		}
		return productRepository.save(product);
	}

	public void deleteProductById(long id) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		Optional<Product> p = productRepository.findById(id);
		if(!(p.isPresent())){
			throw new ProductNotFoundException(p.get().getName());
		}
		productRepository.deleteById(id);
	}

}
