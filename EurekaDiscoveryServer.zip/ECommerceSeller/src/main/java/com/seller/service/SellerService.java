package com.seller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.seller.bean.Seller;
import com.seller.repository.SellerRepository;

@Service
@Transactional
public class SellerService  {
	@Autowired
	SellerRepository sellerRepository;

	public void createSeller(Seller seller) {
		// TODO Auto-generated method stub
		sellerRepository.save(seller);
	}

	public List<Seller> getSeller() {
		// TODO Auto-generated method stub
		return (List<Seller>) sellerRepository.findAll();
	}

	public Seller findById(long id) {
		// TODO Auto-generated method stub
		return sellerRepository.findById(id).get();
		
	}

	public Seller update(Seller seller, long l) {
		// TODO Auto-generated method stub
		return sellerRepository.save(seller);
	}

	public void deleteSellerById(long id) {
		// TODO Auto-generated method stub
		sellerRepository.deleteById(id);
	}

	
	
}
