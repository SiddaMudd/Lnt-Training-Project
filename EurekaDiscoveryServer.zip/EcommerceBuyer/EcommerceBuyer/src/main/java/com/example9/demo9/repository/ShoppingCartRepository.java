package com.example9.demo9.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example9.demo9.model.Buyer;
import com.example9.demo9.model.Product;
import com.example9.demo9.model.ShopingCart;

@Repository
public interface ShoppingCartRepository extends JpaRepository<ShopingCart,Long>{

@Query(value="Select * from dbBuyer.shopping_cart WHERE product_id=:productId AND buyer_id=:buyerId",nativeQuery = true)
public ShopingCart findByProductIdAndBuyerId(long productId,long buyerId );

@Query(value="Select * from dbBuyer.shopping_cart WHERE buyer_id=:buyerId",nativeQuery = true)
public List<ShopingCart> findByBuyerId(long buyerId );

@Query(value="Select * from shopping_cart",nativeQuery = true)
public ShopingCart cartd();

@Modifying
@Transactional
@Query(value="delete  from shopping_cart  WHERE product_id=:productId AND buyer_id=:buyerId ",nativeQuery = true)
public void deleteByProductIdAndBuyerId(long productId,long buyerId );
 
@Modifying
@Transactional
@Query(value="delete  from shopping_cart  WHERE buyer_id=:buyerId ",nativeQuery = true)
public void deleteByProductId(long buyerId);
}
