  package com.example9.demo9.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.example9.demo9.customException.BuyerInvalidException;
import com.example9.demo9.model.Buyer;
import com.example9.demo9.model.Product;
import com.example9.demo9.model.ShopingCart;
import com.example9.demo9.services.BuyerServices;

@RestController
@RequestMapping("/buyer")
public class BuyerController {
	
	@Autowired
	BuyerServices buyerServices;
	
	 @GetMapping(value="/get", headers="Accept=application/json")
	 public String getAllUser() {	 
	  return "hello";
	
	 }
	
	 @PostMapping(value="/create",headers="Accept=application/json")
	 public ResponseEntity<Void> createUser(@RequestBody Product user, UriComponentsBuilder ucBuilder){
	     System.out.println("Creating User "+user.getName());
	     buyerServices.createProduct(user);
	     HttpHeaders headers = new HttpHeaders();
	     headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(user.getId()).toUri());
	     return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	 }
	 
	 @PostMapping(value="/createBuyer",headers="Accept=application/json")
	 public ResponseEntity<Void> createBuyerr(@RequestBody Buyer user, UriComponentsBuilder ucBuilder){
	     System.out.println("Creating User "+user.getUsername());
	     buyerServices.createBuyer(user);
	     HttpHeaders headers = new HttpHeaders();
	     headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(user.getId()).toUri());
	     return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	 }
	 
	 @PostMapping(value="/addToCart/{product_id}/{buyer_id}/{pname}",headers="Accept=application/json")
	 public ResponseEntity<ShopingCart> addToCart(@PathVariable("product_id") long productId,@PathVariable("buyer_id") long buyer_id,@PathVariable("pname") String pname ){
		ShopingCart cart= buyerServices.addToCart(productId, buyer_id, pname);
	     HttpHeaders headers = new HttpHeaders();
//	     headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(user.getId()).toUri());
	     return new ResponseEntity<ShopingCart>(cart, HttpStatus.OK);
	 }
	 
	 @DeleteMapping(value="/removeCart/{productId}/{buyerId}", headers ="Accept=application/json")
		public ResponseEntity<ShopingCart> removeCart(@PathVariable("productId") long product_id,@PathVariable("buyerId") long buyer_id){
			ShopingCart cart = buyerServices.findByProductIdAndBuyerId(product_id, buyer_id);
			
			if (cart == null) {
				return new ResponseEntity<ShopingCart>(HttpStatus.NOT_FOUND);
			}
			 buyerServices.deleteByProductIdAndBuyerId(product_id, buyer_id);

			System.out.println(cart); 
//			buyerServices.deleteSellerById(id);
			return new ResponseEntity<ShopingCart>(cart,HttpStatus.OK);
		}
	 
	 //checkout shopping cart
	 
	 @GetMapping(value="/viewCart/{buyerId}",headers="Accept=application/json")
	 public ResponseEntity<List<ShopingCart>> checkCart(@PathVariable("buyerId") long buyerId) throws BuyerInvalidException{
     System.out.println("****************checking Cart**************************");
		List<ShopingCart> cart = buyerServices.findByBuyerId(buyerId);
		if(cart==null)
		{
			throw new BuyerInvalidException(LocalDateTime.now(), "/checkCart/productId/buyerId", "Shopping Cart is Empty");
		}
		
	     return new ResponseEntity<List<ShopingCart>>(cart, HttpStatus.CREATED);
	 }
	 
	 @DeleteMapping(value="/emptyCart/{buyerId}",headers="Accept=application/json")
	 public void emptyCart(@PathVariable("buyerId") long buyerId) throws BuyerInvalidException{
     System.out.println("****************clearing all Cart**************************");
     buyerServices.emptyCart(buyerId);
     
	 }
	 
	 
	 
}
