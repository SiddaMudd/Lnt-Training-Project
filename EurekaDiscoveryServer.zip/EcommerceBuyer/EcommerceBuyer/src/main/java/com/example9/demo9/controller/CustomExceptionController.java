package com.example9.demo9.controller;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example9.demo9.customException.BuyerInvalidException;
import com.fasterxml.jackson.annotation.JsonFormat;

/*
Date and time
Path
Temporary/Permanent
 */

class BuyerExceptionFields {
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime datetime;
	private String path;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private String message;
	public BuyerExceptionFields(LocalDateTime datetime, String path, String message) {
		super();
		this.datetime = datetime;
		this.path = path;
		this.message = message;
	}
	public LocalDateTime getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String message) {
		this.path = message;
	}
//	public String getType() {
//		return message;
//	}
//	public void setType(String type) {
//		this.message = type;
//	}
	
	
}
@ControllerAdvice
public class CustomExceptionController {
	@ExceptionHandler(value = BuyerInvalidException.class)
	public ResponseEntity<Object> exception(BuyerInvalidException ex) {
		BuyerExceptionFields more_details = new BuyerExceptionFields(ex.getDatetime(),
				ex.getPath(), ex.getMessage());
		
		
		return new ResponseEntity<>(more_details, HttpStatus.NOT_FOUND);
	}
}
