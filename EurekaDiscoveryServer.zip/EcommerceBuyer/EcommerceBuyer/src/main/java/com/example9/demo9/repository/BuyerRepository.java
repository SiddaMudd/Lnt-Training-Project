package com.example9.demo9.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example9.demo9.model.Buyer;
import com.example9.demo9.model.Product;

@Repository
public interface BuyerRepository extends JpaRepository<Buyer,Long>{


}
