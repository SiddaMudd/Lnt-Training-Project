package com.example9.demo9.customException;

import java.time.LocalDateTime;

public class BuyerInvalidException  extends RuntimeException {
	
	private LocalDateTime datetime;
	private String path;
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public BuyerInvalidException(LocalDateTime datetime, String path, String message) {
		super();
		this.datetime = datetime;
		this.path = path;
		this.message = message;
	}
	public LocalDateTime getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
//	public String getType() {
//		return message;
//	}
//	public void setType(String message) {
//		this.message = message;
//	}
	
	

	
//	private int id;
//	private String name;
//	private float price;
//	
//	public ProductIdInvalidException(int id, String name, float price) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.price = price;
//	}
//	
//	
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public float getPrice() {
//		return price;
//	}
//	public void setPrice(float price) {
//		this.price = price;
//	}
	
	
	

}
