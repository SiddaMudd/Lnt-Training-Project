package com.example9.demo9.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example9.demo9.model.Buyer;
import com.example9.demo9.model.Product;
import com.example9.demo9.model.ShopingCart;

public interface BuyerServices {
	
	public void createProduct(Product prod);
	
	public void createBuyer(Buyer buyer);
	
	public ShopingCart addToCart(long product_id,long buyer_id,String pname);
	
	public void deleteByProductIdAndBuyerId(long product_id,long buyer_id );
	
	public ShopingCart findByProductIdAndBuyerId(long product_id,long buyer_id );
	
	public  List<ShopingCart> findByBuyerId(long buyer_id );
		
	public  void  emptyCart(long buyerId);




	

}
