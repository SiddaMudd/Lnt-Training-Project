package com.example9.demo9.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example9.demo9.model.Buyer;
import com.example9.demo9.model.Product;
import com.example9.demo9.model.ShopingCart;
import com.example9.demo9.repository.BuyerRepository;
import com.example9.demo9.repository.ProductRepository;
import com.example9.demo9.repository.ShoppingCartRepository;
import com.example9.demo9.services.BuyerServices;

@Service
public class BuyerServiceImp  implements BuyerServices {
	
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	BuyerRepository buyerRepository;
	
	@Autowired
	ShoppingCartRepository cartRepository;

	@Override
	public void createProduct(Product prod) {
		
		System.out.println("###########################");
		productRepository.save(prod);
		
	}

	@Override
	public void createBuyer(Buyer buyer) {
		System.out.println("###########################");
		buyerRepository.save(buyer);
	}

	@Override
	public ShopingCart addToCart(long productId,long buyerId,String pname)  {
		System.out.println("###########################");
//		cartRepository.save(cart);
		ShopingCart cart=new ShopingCart();
		cart.setProductId(productId);
		cart.setBuyerId(buyerId);
		cart.setPname(pname);
		cartRepository.save(cart);
		return cart;
		
	}

	@Override
	public void deleteByProductIdAndBuyerId(long product_id, long buyer_id) {
		System.out.println("inside delete query");

		cartRepository.deleteByProductIdAndBuyerId(product_id,buyer_id);

	}

	@Override
	public ShopingCart findByProductIdAndBuyerId(long product_id, long buyer_id) {
		System.out.println("inside query");
		ShopingCart cart=cartRepository.findByProductIdAndBuyerId(product_id,buyer_id);
		System.out.println("################## query##################"+cart);

		return cart;
	}

	
	@Override
	public void emptyCart(long buyerId) {
		cartRepository.deleteByProductId(buyerId);
	}

	@Override
	public List<ShopingCart> findByBuyerId(long buyer_id) {
		return cartRepository.findByBuyerId(buyer_id);
	}

}
